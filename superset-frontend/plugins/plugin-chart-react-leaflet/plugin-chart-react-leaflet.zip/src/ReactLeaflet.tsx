/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable import/order */
/* eslint-disable arrow-body-style */
/* eslint-disable prettier/prettier */
/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
// @ts-ignore
// @ts-nocheck
import React, { useEffect, createRef, useState, useRef, useMemo, useCallback } from 'react';
import { styled, ApiV1, DatasourceType } from '@superset-ui/core';
import L from 'leaflet';
import { MapContainer, GeoJSON, TileLayer } from 'react-leaflet';
import { PetaLeafletStylesProps } from './types';
import prov from './maps/prov.json';

import 'leaflet/dist/leaflet.css';



const Container = styled.div<PetaLeafletStylesProps>`
`;
// const Container = styled.div<PetaLeafletStylesProps>`
//  position: relative;    

//  & > * {
//      position: relative;
//      top: 0;
//      left: 0;
//      height: ${({ height }) => height};
//      width: ${({ width }) => width};
//  }

 
//  .leaflet-control-zoom > .leaflet-bar > .leaflet-control{
//      z-index: 10000
//  }

//  .leaflet-control-layers-list{ 
//      width:auto;
//      background-position:3px 50% ;
//      padding:3px;
//      text-decoration:none;
//      line-height:36px;
//      text-align: left;
//      text-transform: uppercase;
//    }

// `

export default function MapLeaflet(props) {

  const [isReady, setIsReady] = useState(false)
  const { data, height, width, formData, datasource } = props;
  const rootElem = createRef<HTMLDivElement>();
  // const [key, setKey] = useState(null);

  const tile = useMemo(() => {
    return L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
      maxZoom: 18,
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, ' +
        'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      id: 'mapLeaflet',
      tileSize: 512,
      zoomOffset: -1
    });
    // return L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    //   attribution:
    //     '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    // })
  }, []);

  // const position = [51.505, -0.09]
  const position=[-2.2753379, 119.4176271];

  return (
    <Container
      ref={rootElem}
      height={height}
      width={width}
    >
      <MapContainer 
      style={{ width, height }}
      center={position} zoom={5} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png"
        />

        <GeoJSON attribution="&copy; credits BPS RI" data={prov} />
      </MapContainer>
    </Container>
  );
}

